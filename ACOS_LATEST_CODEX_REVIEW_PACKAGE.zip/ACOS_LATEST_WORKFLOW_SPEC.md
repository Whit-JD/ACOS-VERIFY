# ACOS Latest Workflow Specification

This file is reconstructed from the latest user-approved ACOS operating direction. It is not a direct export from n8n.

## Target flow

01_소재수집
→ 02_소재평가
→ 03_키워드확장
→ 04_소재DB조회
→ 05_머지
→ 06_본문작성
→ 07_검수
→ 08_이미지전략
→ 09_이미지자산 기록
→ 10_콘텐츠 기록
→ 11_성과 초기화
→ 12_업로드대기

## Operating rules

- Maintain a waiting pool of about 20 candidates.
- Platforms:
  - 네이버블로그: IT / trend / current problem needs
  - 티스토리: 생활 문제 해결형
  - 구글블로그: translated/localized version
- Every content item must include image strategy.
- Output JSON from model nodes must be parseable by later nodes.
- No guessing solutions. Posts must solve actual user search situations.
- Title should feel like a real problem sentence, generally 28 to 42 Korean characters.
- Before publication, status must be 업로드대기 and user approval is required.
- Performance feedback must update ACOS_성과DB and later influence 소재DB scoring.

## Required n8n verification points

1. Node output paths must match actual preceding node JSON.
2. Notion property names must match exactly, including Korean names.
3. Select and multi_select values must already exist in Notion or be handled safely.
4. Number fields must receive numbers, not strings.
5. files/media fields must receive file objects or URLs according to the actual Notion node mode.
6. Merge node must not overwrite keys accidentally.
7. Code nodes must return arrays/items in n8n-compatible format.
8. IF/Switch nodes must not route empty or undefined values into publication steps.
9. Content, image asset, and performance records must share a stable duplicate key or relation strategy.
10. Error path must stop before Notion writes if required JSON is malformed.
